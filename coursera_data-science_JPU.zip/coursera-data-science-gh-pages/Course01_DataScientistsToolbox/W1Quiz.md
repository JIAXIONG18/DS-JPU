# Week 1 Quiz

1. Which of the following are courses in the Data Science Specialization? Select all that apply
 - **Exploratory Data Analysis**
 - **Statistical Inference**
 - Python Programming
 - Introduction to Hadoop

2. Why are we using R for the course track? Select all that apply.
 - **R has a large number of add on packages that are useful for data analysis.**
 - R allows object oriented programming.
 - **R is free.**
 - R is a general purpose programming language.
 - **R has a nice IDE, Rstudio.**

3. What are good ways to  nd answers to questions in this course track? Select all that apply.
 - **Searching Google.**
 - Emailing the community TAs
 - **Posting to the course discussion forum**
 - Posting homework assignments to mailing lists

4. What are characteristics of good questions on the message boards? Select all that apply.
 - **Provides the minimum amount of information necessary to communicate the problem.**
 - **Includes follow-ups if you answer your own question.**
 - Asks for a code fix without explanation.
 - Provides no details.

5. Which of the following packages provides machine learning functionality? Select all that apply
 - knitr
 - **pamr**
 - shiny
 - **gbm**
